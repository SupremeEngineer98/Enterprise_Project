import React from 'react';
import { Twitter, Github, Linkedin } from 'lucide-react';
import logoImg from "figma:asset/3d1d3da4c722cb70b319e04b965451fdf1bf7199.png";

export const Footer = () => {
  return (
    <footer className="bg-black border-t border-white/10 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-3">
            <img src={logoImg} alt="Wise Win Logo" className="h-12 w-auto" />
            <div>
              <span className="text-xs text-gray-500 tracking-widest uppercase block">Video Game Studio</span>
            </div>
          </div>

          <div className="flex gap-6">
            <a href="#" className="text-gray-400 hover:text-white transition-colors">
              <Twitter className="w-6 h-6" />
            </a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">
              <Github className="w-6 h-6" />
            </a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">
              <Linkedin className="w-6 h-6" />
            </a>
          </div>

          <div className="text-gray-500 text-sm">
            © 2026 Wise Win. Με επιφύλαξη παντός δικαιώματος.
          </div>
        </div>
      </div>
    </footer>
  );
};
