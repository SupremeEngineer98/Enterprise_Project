import React from 'react';
import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import logoImg from "figma:asset/3d1d3da4c722cb70b319e04b965451fdf1bf7199.png";

export const About = () => {
  return (
    <section id="about" className="py-24 bg-zinc-950 text-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl font-bold mb-6 text-purple-500">Η εταιρεία μας</h2>
            <p className="text-xl text-gray-300 leading-relaxed mb-6">
              Η <span className="text-white font-semibold">Wise Win</span> είναι ένα studio ανάπτυξης βιντεοπαιχνιδιών με έδρα την Ελλάδα. Αποτελούμαστε από μια ομάδα δημιουργικών καλλιτεχνών, προγραμματιστών και αφηγητών που μοιράζονται το ίδιο πάθος: την δημιουργία αξέχαστων εμπειριών.
            </p>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="mt-1 w-2 h-2 rounded-full bg-yellow-400 shrink-0" />
                <div>
                  <h3 className="text-lg font-bold text-white">Ο Σκοπός μας</h3>
                  <p className="text-gray-400">Να επαναπροσδιορίσουμε τον τρόπο που οι παίκτες αλληλεπιδρούν με τους ψηφιακούς κόσμους, δίνοντας έμφαση στην καινοτομία και το συναίσθημα.</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="mt-1 w-2 h-2 rounded-full bg-purple-500 shrink-0" />
                <div>
                  <h3 className="text-lg font-bold text-white">Το Όραμά μας</h3>
                  <p className="text-gray-400">Να γίνουμε ένας παγκόσμιος ηγέτης στην βιομηχανία του gaming, αναδεικνύοντας το ταλέντο και την δημιουργικότητα της περιοχής μας.</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="absolute -inset-4 bg-purple-600/20 blur-3xl rounded-full" />
            <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-zinc-900 p-12 flex items-center justify-center">
              <img
                src={logoImg}
                alt="Wise Win Logo"
                className="w-full max-w-md object-contain"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
