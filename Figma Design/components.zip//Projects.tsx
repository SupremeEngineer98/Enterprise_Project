import React from 'react';
import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const projects = [
  {
    title: "Night Owl: Chronicles",
    category: "Action RPG",
    image: "https://images.unsplash.com/photo-1611770830979-c9451af1a2bd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjeWJlcnB1bmslMjB2aWRlbyUyMGdhbWUlMjBzY2VuZXJ5fGVufDF8fHx8MTc3MDQwMTc4MHww",
    description: "Ένα σκοτεινό RPG δράσης σε έναν κυβερνοπάνκ κόσμο."
  },
  {
    title: "Wise Forest",
    category: "Adventure",
    image: "https://images.unsplash.com/photo-1758862493208-2046897d09d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW50YXN5JTIwZm9yZXN0JTIwdmlkZW8lMjBnYW1lJTIwYXJ0fGVufDF8fHx8MTc3MDQwMTc4MHww",
    description: "Εξερευνήστε ένα μαγικό δάσος γεμάτο γρίφους και μυστικά."
  },
  {
    title: "Binary Dreams",
    category: "Puzzle",
    image: "https://images.unsplash.com/photo-1765196176394-e028da216775?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaXhlbCUyMGFydCUyMGdhbWUlMjBkZXZlbG9wZXIlMjB3b3Jrc3BhY2V8ZW58MXx8fHwxNzcwNDAxNzgwfDA",
    description: "Ένα indie puzzle game με μοναδικό pixel art στυλ."
  }
];

export const Projects = () => {
  return (
    <section id="projects" className="py-24 bg-black text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl font-bold mb-4"
          >
            Τα Έργα μας
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-gray-400 max-w-2xl mx-auto"
          >
            Μια ματιά στα παιχνίδια που αναπτύσσουμε και στις εμπειρίες που έχουμε δημιουργήσει.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative bg-zinc-900 rounded-xl overflow-hidden border border-white/5 hover:border-indigo-500/50 transition-all duration-300"
            >
              <div className="aspect-video overflow-hidden">
                <ImageWithFallback
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="p-6">
                <span className="text-purple-400 text-sm font-bold uppercase tracking-wider">{project.category}</span>
                <h3 className="text-xl font-bold mt-2 mb-2 group-hover:text-yellow-400 transition-colors">{project.title}</h3>
                <p className="text-gray-400 text-sm">{project.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
