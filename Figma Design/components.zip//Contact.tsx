import React from 'react';
import { Mail, MessageSquare, Send } from 'lucide-react';
import { motion } from 'motion/react';

export const Contact = () => {
  return (
    <section id="contact" className="py-24 bg-zinc-950 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-6">Επικοινωνία</h2>
            <p className="text-gray-400 mb-8 text-lg">
              Έχετε μια ιδέα για παιχνίδι; Θέλετε να συνεργαστούμε; Ή απλά θέλετε να πείτε ένα γεια; Είμαστε εδώ για εσάς.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-center gap-4 group">
                <div className="w-12 h-12 bg-purple-600/10 rounded-full flex items-center justify-center group-hover:bg-purple-600 transition-colors">
                  <Mail className="w-6 h-6 text-purple-500 group-hover:text-white" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Email Us</p>
                  <a href="mailto:info@wisewin.gr" className="text-lg font-bold hover:text-purple-400 transition-colors">
                    info@wisewin.gr
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-4 group">
                <div className="w-12 h-12 bg-purple-600/10 rounded-full flex items-center justify-center group-hover:bg-purple-600 transition-colors">
                  <MessageSquare className="w-6 h-6 text-purple-500 group-hover:text-white" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Social Media</p>
                  <p className="text-lg font-bold">@WiseWinGames</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-black/40 p-8 rounded-2xl border border-white/10"
          >
            <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Όνομα</label>
                <input
                  type="text"
                  className="w-full bg-zinc-900 border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                  placeholder="Το όνομά σας"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Email</label>
                <input
                  type="email"
                  className="w-full bg-zinc-900 border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                  placeholder="email@example.com"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Μήνυμα</label>
                <textarea
                  rows={4}
                  className="w-full bg-zinc-900 border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                  placeholder="Πώς μπορούμε να βοηθήσουμε;"
                ></textarea>
              </div>
              <button
                type="submit"
                className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2 transition-all transform active:scale-95"
              >
                Αποστολή <Send className="w-4 h-4" />
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
